# ColorDream 🎨

KI-gestützte Schwarz-Weiß Kolorierung mit Pinsel-Zeitraffer Animation.

## Deployment in 5 Minuten

### Schritt 1 — GitHub Repository erstellen
1. Geh auf github.com → "New repository"
2. Name: `colordream`
3. Public oder Private → "Create repository"

### Schritt 2 — Dateien hochladen
1. Klick auf "uploading an existing file"
2. Lade den ganzen `colordream-app` Ordner hoch
3. Commit: "Initial commit" → "Commit changes"

### Schritt 3 — Vercel verbinden
1. Geh auf vercel.com → "Sign up" mit GitHub
2. "New Project" → dein `colordream` Repo wählen
3. Framework: **Next.js** (automatisch erkannt)
4. Klick auf "Environment Variables" und füge hinzu:
   - Name: `REPLICATE_API_KEY`
   - Value: `r8_addXpdAAkw6TifQ8eh9w0A4T8rm9IQM3FMv4R`
5. "Deploy" klicken
6. Fertig! Du bekommst eine URL wie `colordream.vercel.app`

## Lokale Entwicklung

```bash
npm install
npm run dev
```

Dann http://localhost:3000 öffnen.

Erstelle eine `.env.local` Datei:
```
REPLICATE_API_KEY=r8_addXpdAAkw6TifQ8eh9w0A4T8rm9IQM3FMv4R
```
