export default async function handler(req, res) {
  // Allow CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const apiKey = process.env.REPLICATE_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'REPLICATE_API_KEY nicht gesetzt' });

  try {
    const { image } = req.body;
    if (!image) return res.status(400).json({ error: 'Kein Bild übergeben' });

    // Start prediction
    const startResp = await fetch('https://api.replicate.com/v1/models/piddnad/ddcolor/predictions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        input: { image, model_size: 'large' }
      })
    });

    if (!startResp.ok) {
      const err = await startResp.json().catch(() => ({}));
      return res.status(startResp.status).json({ error: err.detail || 'Replicate Fehler' });
    }

    const prediction = await startResp.json();
    const pollUrl = prediction.urls?.get || `https://api.replicate.com/v1/predictions/${prediction.id}`;

    // Poll until done (max 3 minutes)
    for (let i = 0; i < 90; i++) {
      await new Promise(r => setTimeout(r, 2000));

      const pollResp = await fetch(pollUrl, {
        headers: { 'Authorization': `Bearer ${apiKey}` }
      });
      const result = await pollResp.json();

      if (result.status === 'succeeded') {
        const output = result.output;
        const url = Array.isArray(output) ? output[0] : output;
        return res.status(200).json({ url });
      }
      if (result.status === 'failed' || result.status === 'canceled') {
        return res.status(500).json({ error: `Prediction ${result.status}: ${result.error || ''}` });
      }
    }

    return res.status(504).json({ error: 'Timeout: KI hat zu lange gebraucht' });

  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}

export const config = {
  api: { bodyParser: { sizeLimit: '10mb' } }
};
