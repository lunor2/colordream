import { useState, useRef } from 'react';
import Head from 'next/head';

const BRUSHES = [
  { id: 'sweep', label: '🖌️ Pinsel' },
  { id: 'rain', label: '🌧️ Regen' },
  { id: 'wave', label: '🌊 Welle' },
  { id: 'spiral', label: '🌀 Spirale' },
  { id: 'splatter', label: '💥 Spritzer' },
  { id: 'center', label: '✨ Explosion' },
];

export default function Home() {
  const [srcImg, setSrcImg] = useState(null);
  const [srcFile, setSrcFile] = useState(null);
  const [brush, setBrush] = useState('sweep');
  const [frames, setFrames] = useState(60);
  const [delay, setDelay] = useState(35);
  const [step, setStep] = useState(0); // 0=idle 1=ai 2=render 3=encode
  const [progress, setProgress] = useState(0);
  const [progLabel, setProgLabel] = useState('');
  const [error, setError] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [gifUrl, setGifUrl] = useState('');
  const canvasRef = useRef(null);

  function handleFile(f) {
    if (!f) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const img = new Image();
      img.onload = () => {
        setSrcImg(img);
        setSrcFile({ name: f.name, w: img.width, h: img.height });
        setError(''); setVideoUrl(''); setGifUrl(''); setStep(0);
        drawGray(img);
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(f);
  }

  function drawGray(img) {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    const mx = 600; let w = img.width, h = img.height;
    if (w > mx) { h = Math.round(h * mx / w); w = mx; }
    c.width = w; c.height = h;
    ctx.drawImage(img, 0, 0, w, h);
    const id = ctx.getImageData(0, 0, w, h);
    for (let i = 0; i < id.data.length; i += 4) {
      const g = id.data[i] * 0.299 + id.data[i + 1] * 0.587 + id.data[i + 2] * 0.114;
      id.data[i] = id.data[i + 1] = id.data[i + 2] = g;
    }
    ctx.putImageData(id, 0, 0);
  }

  async function run() {
    if (!srcImg) return;
    setError(''); setVideoUrl(''); setGifUrl('');

    // Step 1: AI colorize via our API route
    setStep(1); setProgress(10); setProgLabel('KI Kolorierung startet...');
    let colorizedUrl;
    try {
      const c = document.createElement('canvas');
      const ctx = c.getContext('2d');
      let w = srcImg.width, h = srcImg.height;
      if (w > 1024) { h = Math.round(h * 1024 / w); w = 1024; }
      c.width = w; c.height = h;
      ctx.drawImage(srcImg, 0, 0, w, h);
      const dataUrl = c.toDataURL('image/jpeg', 0.92);

      setProgress(20); setProgLabel('Bild wird an KI gesendet...');
      const resp = await fetch('/api/colorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: dataUrl })
      });
      const data = await resp.json();
      if (!resp.ok || data.error) throw new Error(data.error || 'API Fehler');
      colorizedUrl = data.url;
      setProgress(100); setProgLabel('Kolorierung fertig ✓');
    } catch (e) {
      setError('KI Fehler: ' + e.message);
      setStep(0); return;
    }

    // Load colorized image
    const colImg = await new Promise((res, rej) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => res(img);
      img.onerror = () => { const i2 = new Image(); i2.onload=()=>res(i2); i2.onerror=()=>rej(new Error('Bild laden fehlgeschlagen')); i2.src=colorizedUrl; };
      img.src = colorizedUrl;
    });

    // Step 2: Render frames
    setStep(2); setProgress(0); setProgLabel('Frames werden gerendert...');
    const allFrames = await renderFrames(colImg, frames, brush, setProgress, setProgLabel);

    // Step 3: Encode
    setStep(3); setProgress(0); setProgLabel('Video wird erstellt...');
    await encode(allFrames, delay, setProgress, setProgLabel, setVideoUrl, setGifUrl);
    setStep(4);
  }

  async function renderFrames(colImg, total, brush, setP, setL) {
    const c = canvasRef.current;
    const ctx = c.getContext('2d');
    const w = c.width, h = c.height;

    const tmp = document.createElement('canvas'); tmp.width = w; tmp.height = h;
    const tc = tmp.getContext('2d');

    tc.drawImage(srcImg, 0, 0, w, h);
    const gRaw = tc.getImageData(0, 0, w, h);
    const gray = new Uint8ClampedArray(gRaw.data.length);
    for (let i = 0; i < gRaw.data.length; i += 4) {
      const g = Math.round(gRaw.data[i] * 0.299 + gRaw.data[i + 1] * 0.587 + gRaw.data[i + 2] * 0.114);
      gray[i] = gray[i + 1] = gray[i + 2] = g; gray[i + 3] = 255;
    }

    tc.clearRect(0, 0, w, h);
    try { tc.drawImage(colImg, 0, 0, w, h); } catch(e) { tc.drawImage(srcImg, 0, 0, w, h); }
    const color = tc.getImageData(0, 0, w, h).data;

    const result = [];
    for (let f = 0; f <= total; f++) {
      renderBrush(ctx, gray, color, w, h, f / total, brush);
      setP(Math.round((f / total) * 100));
      setL(`Frame ${f} / ${total}`);
      result.push(ctx.getImageData(0, 0, w, h));
      await sleep(2);
    }
    return result;
  }

  async function encode(frameList, delay, setP, setL, setVid, setGif) {
    const c = canvasRef.current;
    const w = c.width, h = c.height;

    try {
      const stream = c.captureStream(0);
      const mimeType = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'].find(t => MediaRecorder.isTypeSupported(t));
      if (!mimeType) throw new Error('no webm');
      const chunks = [];
      const mr = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 8000000 });
      mr.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
      mr.start();
      for (let f = 0; f < frameList.length; f++) {
        c.getContext('2d').putImageData(frameList[f], 0, 0);
        setP(Math.round((f / frameList.length) * 100));
        setL(`Video kodieren... ${Math.round((f / frameList.length) * 100)}%`);
        if (stream.getVideoTracks()[0].requestFrame) stream.getVideoTracks()[0].requestFrame();
        await sleep(delay);
      }
      await sleep(300); mr.stop();
      await new Promise(res => { mr.onstop = res; });
      const blob = new Blob(chunks, { type: 'video/webm' });
      if (blob.size < 2000) throw new Error('too small');
      setVid(URL.createObjectURL(blob));
      setP(100); setL('✓ Video fertig!');
    } catch (e) {
      // GIF fallback
      setL('GIF wird erstellt (Fallback)...');
      await new Promise(res => {
        const gif = new (window.GIF)({ workers: 2, quality: 8, width: w, height: h, workerScript: 'https://cdnjs.cloudflare.com/ajax/libs/gif.js/0.2.0/gif.worker.js' });
        frameList.forEach(id => {
          const fc = document.createElement('canvas'); fc.width = w; fc.height = h;
          fc.getContext('2d').putImageData(id, 0, 0);
          gif.addFrame(fc, { delay, copy: true });
        });
        gif.on('progress', p => { setP(Math.round(p * 100)); setL(`GIF kodieren... ${Math.round(p * 100)}%`); });
        gif.on('finished', blob => { setGif(URL.createObjectURL(blob)); setP(100); setL('✓ GIF fertig!'); res(); });
        gif.render();
      });
    }
  }

  function renderBrush(ctx, gray, color, w, h, progress, brush) {
    const id = ctx.createImageData(w, h), px = id.data;
    for (let i = 0; i < w * h; i++) {
      const x = i % w, y = Math.floor(i / w);
      const nx = x / w, ny = y / h;
      let reveal = 0;
      if (brush === 'sweep') {
        reveal = smoothstep(nx - (noise(y * 0.03, 0, 0) - 0.5) * 0.12, progress - 0.1, progress + 0.05);
      } else if (brush === 'rain') {
        const off = noise(Math.floor(nx * 40) * 0.7, 0, 0) * 0.4;
        const dp = clamp((progress - off) / (1 - off));
        reveal = ny < dp ? smoothstep(ny, dp - 0.06, dp) : 0;
      } else if (brush === 'wave') {
        reveal = smoothstep(nx + Math.sin(ny * Math.PI * 3 + progress * 4) * 0.06, progress - 0.08, progress + 0.08);
      } else if (brush === 'spiral') {
        const cx = nx - 0.5, cy = ny - 0.5;
        const angle = (Math.atan2(cy, cx) + Math.PI) / (Math.PI * 2);
        const dist = Math.sqrt(cx * cx + cy * cy) * 1.5;
        const spin = (angle + dist * 0.5) % 1;
        reveal = clamp((spin < progress ? 1 : 0) + noise(x * 0.04, y * 0.04, progress) * 0.15);
      } else if (brush === 'splatter') {
        const thr = noise(x * 0.05, y * 0.05, 0) * 0.7 + noise(x * 0.02, y * 0.02, 1) * 0.3;
        reveal = thr < progress ? smoothstep(thr, progress - 0.04, progress) : 0;
      } else if (brush === 'center') {
        const dx = nx - 0.5, dy = ny - 0.5;
        const dist = Math.sqrt(dx * dx + dy * dy) * 1.42 + noise(x * 0.03, y * 0.03, 0) * 0.08;
        reveal = dist < progress ? 1 : smoothstep(dist, progress, progress + 0.08);
      }
      reveal = clamp(reveal);
      const j = i * 4;
      px[j] = Math.round(gray[j] + (color[j] - gray[j]) * reveal);
      px[j + 1] = Math.round(gray[j + 1] + (color[j + 1] - gray[j + 1]) * reveal);
      px[j + 2] = Math.round(gray[j + 2] + (color[j + 2] - gray[j + 2]) * reveal);
      px[j + 3] = 255;
    }
    ctx.putImageData(id, 0, 0);
  }

  const busy = step > 0 && step < 4;

  return (
    <>
      <Head>
        <title>ColorDream</title>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Syne+Mono&family=Inter:wght@300;400;500&display=swap" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/gif.js/0.2.0/gif.js"></script>
      </Head>
      <style>{`
        *{margin:0;padding:0;box-sizing:border-box}
        :root{--bg:#080b10;--border:rgba(255,255,255,0.07);--accent:#00e5ff;--accent2:#ff6b35;--text:#e8edf2;--muted:rgba(232,237,242,0.38);--success:#00ff88}
        body{background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;min-height:100vh}
        body::before{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(0,229,255,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(0,229,255,0.025) 1px,transparent 1px);background-size:40px 40px;pointer-events:none;z-index:0}
        input[type=range]{-webkit-appearance:none;width:100%;height:2px;background:rgba(255,255,255,0.08);border-radius:2px;outline:none}
        input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;border-radius:50%;background:var(--accent);cursor:pointer;box-shadow:0 0 8px rgba(0,229,255,0.5)}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}
      `}</style>

      <div style={{position:'relative',zIndex:1}}>
        {/* HEADER */}
        <header style={{padding:'1.8rem 3rem',display:'flex',alignItems:'center',gap:'2rem',borderBottom:'1px solid var(--border)',backdropFilter:'blur(10px)',position:'sticky',top:0,zIndex:100,background:'rgba(8,11,16,0.88)'}}>
          <div>
            <div style={{fontFamily:'Syne',fontWeight:800,fontSize:'1.6rem',letterSpacing:'-0.02em',color:'var(--accent)',textShadow:'0 0 30px rgba(0,229,255,0.4)'}}>
              Color<span style={{color:'var(--accent2)'}}>Dream</span>
            </div>
            <div style={{fontSize:'0.78rem',color:'var(--muted)',letterSpacing:'0.08em',textTransform:'uppercase',fontWeight:300}}>
              Replicate DDColor · Pinsel Animation · Video Export
            </div>
          </div>
          <div style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:'0.5rem',fontSize:'0.72rem',color:'var(--muted)'}}>
            <div style={{width:7,height:7,borderRadius:'50%',background:'var(--success)',boxShadow:'0 0 8px var(--success)',animation:'pulse 2s infinite'}}></div>
            Replicate DDColor
          </div>
        </header>

        {/* APP */}
        <div style={{display:'grid',gridTemplateColumns:'400px 1fr',minHeight:'calc(100vh - 73px)'}}>

          {/* SIDEBAR */}
          <div style={{padding:'2.5rem 2rem',borderRight:'1px solid var(--border)',display:'flex',flexDirection:'column',gap:'2rem',overflowY:'auto'}}>

            {/* Upload */}
            <div>
              <SectionTitle>01 Bild hochladen</SectionTitle>
              <div
                onClick={()=>document.getElementById('fi').click()}
                onDragOver={e=>e.preventDefault()}
                onDrop={e=>{e.preventDefault();handleFile(e.dataTransfer.files[0])}}
                style={{border:'1px solid var(--border)',borderRadius:12,padding:'2.5rem 1.5rem',textAlign:'center',cursor:'pointer',background:'rgba(0,229,255,0.02)',transition:'all 0.3s'}}
              >
                <div style={{fontSize:'2.8rem',marginBottom:'1rem'}}>🖼️</div>
                <div style={{fontFamily:'Syne',fontWeight:700,fontSize:'0.95rem',marginBottom:'0.4rem'}}>Schwarz-Weiß Bild</div>
                <div style={{fontSize:'0.78rem',color:'var(--muted)'}}>JPG · PNG · WebP<br/>Klicken oder reinziehen</div>
              </div>
              <input id="fi" type="file" accept="image/*" style={{display:'none'}} onChange={e=>handleFile(e.target.files[0])} />
            </div>

            {srcFile && (
              <div>
                <SectionTitle>Vorschau</SectionTitle>
                <canvas ref={canvasRef} style={{width:'100%',borderRadius:8,border:'1px solid var(--border)',background:'#000'}} />
                <div style={{fontSize:'0.7rem',color:'var(--muted)',marginTop:'0.4rem',fontFamily:'Syne Mono'}}>{srcFile.name} · {srcFile.w}×{srcFile.h}</div>
              </div>
            )}

            {!srcFile && <canvas ref={canvasRef} style={{display:'none'}} />}

            {/* Brush */}
            <div>
              <SectionTitle>02 Pinsel-Stil</SectionTitle>
              <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:'0.5rem'}}>
                {BRUSHES.map(b=>(
                  <button key={b.id} onClick={()=>setBrush(b.id)} style={{padding:'0.65rem 0.5rem',border:`1px solid ${brush===b.id?'var(--accent)':'var(--border)'}`,borderRadius:8,background:brush===b.id?'rgba(0,229,255,0.08)':'rgba(255,255,255,0.02)',color:brush===b.id?'var(--accent)':'var(--muted)',fontSize:'0.75rem',cursor:'pointer',fontFamily:'Inter',transition:'all 0.2s'}}>
                    {b.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Settings */}
            <div>
              <SectionTitle>03 Einstellungen</SectionTitle>
              <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
                <div>
                  <label style={{fontSize:'0.75rem',color:'var(--muted)',display:'flex',justifyContent:'space-between',marginBottom:'0.4rem'}}>
                    Frames <em style={{color:'var(--accent)',fontStyle:'normal',fontFamily:'Syne Mono'}}>{frames}</em>
                  </label>
                  <input type="range" min="20" max="120" step="10" value={frames} onChange={e=>setFrames(+e.target.value)} />
                </div>
                <div>
                  <label style={{fontSize:'0.75rem',color:'var(--muted)',display:'flex',justifyContent:'space-between',marginBottom:'0.4rem'}}>
                    Frame Delay <em style={{color:'var(--accent)',fontStyle:'normal',fontFamily:'Syne Mono'}}>{delay}ms</em>
                  </label>
                  <input type="range" min="16" max="150" step="1" value={delay} onChange={e=>setDelay(+e.target.value)} />
                </div>
              </div>
            </div>

            <button
              onClick={run}
              disabled={!srcImg || busy}
              style={{padding:'1rem',background:busy||!srcImg?'rgba(0,229,255,0.15)':'linear-gradient(135deg,var(--accent),#0099bb)',color:busy||!srcImg?'var(--muted)':'#000',border:'none',borderRadius:10,fontFamily:'Syne',fontWeight:800,fontSize:'1rem',letterSpacing:'0.05em',cursor:!srcImg||busy?'not-allowed':'pointer',transition:'all 0.25s'}}
            >
              {busy ? '⏳ Verarbeite...' : '▶ Zeitraffer erstellen'}
            </button>
          </div>

          {/* MAIN */}
          <div style={{padding:'2.5rem',display:'flex',flexDirection:'column',gap:'1.5rem'}}>

            {/* Steps */}
            <div style={{display:'flex'}}>
              {['① KI Kolorierung','② Frames rendern','③ Video exportieren'].map((s,i)=>(
                <div key={i} style={{flex:1,padding:'0.6rem 0.5rem',fontSize:'0.68rem',textAlign:'center',color:step===i+1?'var(--accent)':step>i+1?'var(--success)':'var(--muted)',borderBottom:`2px solid ${step===i+1?'var(--accent)':step>i+1?'var(--success)':'var(--border)'}`,transition:'all 0.3s',letterSpacing:'0.05em',textTransform:'uppercase'}}>
                  {s}
                </div>
              ))}
            </div>

            {/* Stage */}
            <div style={{position:'relative',background:'#000',borderRadius:12,border:'1px solid var(--border)',overflow:'hidden',display:'flex',alignItems:'center',justifyContent:'center',minHeight:320,flex:1}}>
              {!srcFile && (
                <div style={{position:'absolute',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:'1rem',color:'rgba(255,255,255,0.08)'}}>
                  <div style={{fontSize:'4rem',opacity:0.15}}>🎨</div>
                  <div style={{fontSize:'0.8rem',letterSpacing:'0.1em',textTransform:'uppercase'}}>Bild hochladen um zu starten</div>
                </div>
              )}
              {srcFile && <canvas ref={canvasRef} style={{maxWidth:'100%',maxHeight:460,display:'block'}} />}
            </div>

            {/* Error */}
            {error && (
              <div style={{background:'rgba(255,80,80,0.08)',border:'1px solid rgba(255,80,80,0.25)',borderRadius:8,padding:'1rem',fontSize:'0.8rem',color:'#ff8080',whiteSpace:'pre-wrap',lineHeight:1.6}}>
                {error}
              </div>
            )}

            {/* Progress */}
            {busy && (
              <div style={{display:'flex',flexDirection:'column',gap:'0.8rem'}}>
                <div style={{height:3,background:'rgba(255,255,255,0.06)',borderRadius:2,overflow:'hidden'}}>
                  <div style={{height:'100%',width:progress+'%',background:step===1?'linear-gradient(90deg,#ff6b35,#ffb347)':step===2?'linear-gradient(90deg,var(--accent),#00ff88)':'linear-gradient(90deg,#a855f7,var(--accent))',transition:'width 0.2s',borderRadius:2}} />
                </div>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:'0.72rem',color:'var(--muted)',fontFamily:'Syne Mono'}}>
                  <span>{progLabel}</span>
                  <span style={{color:'var(--accent)'}}>{progress}%</span>
                </div>
              </div>
            )}

            {/* Result */}
            {(videoUrl || gifUrl) && (
              <div style={{display:'flex',flexDirection:'column',gap:'1rem'}}>
                <SectionTitle>Fertiges Video</SectionTitle>
                {videoUrl && <video src={videoUrl} controls loop autoPlay muted playsInline style={{width:'100%',borderRadius:8,border:'1px solid var(--border)'}} />}
                {gifUrl && <img src={gifUrl} alt="GIF" style={{width:'100%',borderRadius:8,border:'1px solid var(--border)'}} />}
                <div style={{display:'flex',gap:'0.75rem'}}>
                  <a href={videoUrl||gifUrl} download={videoUrl?'colordream.webm':'colordream.gif'} style={{flex:1,padding:'0.75rem',textAlign:'center',textDecoration:'none',background:'rgba(0,255,136,0.08)',border:'1px solid rgba(0,255,136,0.25)',color:'var(--success)',borderRadius:8,fontSize:'0.82rem'}}>
                    ⬇ {videoUrl?'Video':'GIF'} herunterladen
                  </a>
                  <button onClick={()=>{setVideoUrl('');setGifUrl('');setStep(0);setSrcImg(null);setSrcFile(null);setError('');}} style={{flex:1,padding:'0.75rem',background:'rgba(255,255,255,0.04)',border:'1px solid var(--border)',color:'var(--muted)',borderRadius:8,fontSize:'0.82rem',cursor:'pointer',fontFamily:'Inter'}}>
                    ↺ Neu starten
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

function SectionTitle({children}) {
  return (
    <div style={{fontFamily:'Syne Mono',fontSize:'0.6rem',letterSpacing:'0.3em',color:'var(--accent)',textTransform:'uppercase',marginBottom:'0.8rem',display:'flex',alignItems:'center',gap:'0.5rem'}}>
      {children}
      <div style={{flex:1,height:1,background:'linear-gradient(90deg,rgba(255,255,255,0.07),transparent)'}} />
    </div>
  );
}

function smoothstep(x,e0,e1){const t=clamp((x-e0)/(e1-e0));return t*t*(3-2*t);}
function clamp(v){return Math.max(0,Math.min(1,v));}
function noise(x,y,z){const n=Math.sin(x*127.1+y*311.7+z*74.3)*43758.5453;return n-Math.floor(n);}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
